import React from 'react';
import SocialLinks from '../Header/SocialLinks';

const Footer = () => {
    return (
        <footer>
            <SocialLinks />
            {/* Additional Footer Content */}
        </footer>
    );
};

export default Footer;
