// SocialLinks.tsx
import React from 'react';

const SocialLinks = () => {
    return (
        <div>
            <a href="YOUR_LINKEDIN_URL" target="_blank" rel="noopener noreferrer">
                <img src="/images/social-icons/linkedin.png" alt="LinkedIn" />
            </a>
            <a href="YOUR_INSTAGRAM_URL" target="_blank" rel="noopener noreferrer">
                <img src="/images/social-icons/instagram.png" alt="Instagram" />
            </a>
            <a href="YOUR_FACEBOOK_URL" target="_blank" rel="noopener noreferrer">
                <img src="/images/social-icons/facebook.png" alt="Facebook" />
            </a>
        </div>
    );
};

export default SocialLinks;
