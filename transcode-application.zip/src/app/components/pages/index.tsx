// src/app/pages/index.tsx
import React from 'react';
import RootLayout from '@/app/layout'; 

const Home = () => {
    return (
        <RootLayout>
            <div>
                <h1>Welcome to My Next.js App!</h1>
                {/* Your Home Page Content */}
            </div>
        </RootLayout>
    );
};

export default Home;
